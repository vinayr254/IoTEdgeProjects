# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for
# license information.
# --------------------------------------------------------------------------

import sys
import os
import msrest
from azure.iot.hub import DigitalTwinClient


iothub_connection_str = os.getenv("IOTHUB_CONNECTION_STRING")
device_id = os.getenv("IOTHUB_DEVICE_ID")

try:
    # Create DigitalTwinClient
    digital_twin_client = DigitalTwinClient.from_connection_string(iothub_connection_str)

    # If you already have a component thermostat1:
    # patch = [{"op": "replace", "path": "/thermostat1/targetTemperature", "value": 42}]
    patch = [{"op": "add", "path": "/targetTemperature", "value": 42}]
    digital_twin_client.update_digital_twin(device_id, patch)
    print("Patch has been successfully applied")


except msrest.exceptions.HttpOperationError as ex:
    print("HttpOperationError error {0}".format(ex.response.text))
except Exception as exc:
    print("Unexpected error {0}".format(exc))
except KeyboardInterrupt:
    print("{} stopped".format(__file__))
finally:
    print("{} finished".format(__file__))
