# azure-iothub-service-client is now azure-iot-hub

This package has been renamed. Use `pip install azure-iot-hub` instead.

New package: [https://pypi.org/project/azure-iot-hub/](https://pypi.org/project/azure-iot-hub/)

The new package contains many breaking changes to APIs from the 1.x versions. Please see the [samples](https://github.com/Azure/azure-iot-sdk-python/tree/main/azure-iot-hub/samples) for details.

If you still need to use the old 1.x version APIs, the archival source code is still available [here](https://github.com/Azure/azure-iot-sdk-python/tree/v1-deprecated).

Note that 1.x is fully deprecated and no longer supported.
