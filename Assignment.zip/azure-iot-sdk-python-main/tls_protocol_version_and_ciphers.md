# IoT Python SDK support for TLS 1.2

## TLS Version

The Python SDK fully supports TLS 1.2 in all of its APIs.

Due to security concerns the Python SDK does not allow TLS 1.1 connections.

## TLS Cipher Suites

Coming Soon
